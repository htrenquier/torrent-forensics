YAMIPOD README
(PLEASE READ CAREFULLY)

This program is distribuited in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
There's no email support, so use at own risk.

Please keep in mind this software may NOT WORK and COULD DAMAGE 
your data, so backup everything before using it, even if there 
is a restore feature.

YamiPod for linux uses FMODEx (http://www.fmod.org), a cross platform audio library. You'll find a file called libfmodex.so.4.* that has to be copied to your library folder (usually /usr/lib).
If you're getting "Playing the sound failed" error please see the FAQ.

Refer to http://www.yamipod.com for more informations about installation and usage.